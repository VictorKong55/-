close all;
clc;
startup_rvc

%加载模型
mdl_puma560

%编写条件
t0 = 0;
t1 = 5;
t2 = t1 + 5;
t3 = t2 + 5;

t0_1 = 0:0.5:5;
t1_2 = 0:0.5:5;
t2_3 = 0:0.5:5;

aim0 = [0,-0.5,-0.5];
aim1 = [0,-0.5,0.2];
aim2 = [-0.5,0.5,0.2];
aim3 = [-0.5,0.5,-0.5];
    

T0 = transl(aim0);
T1 = transl(aim1);
T2 = transl(aim2);
T3 = transl(aim3);

theta0 = p560.ikine6s(T0,'rdf');
theta1 = p560.ikine6s(T1,'rdf');
theta2 = p560.ikine6s(T2,'rdf');
theta3 = p560.ikine6s(T3,'rdf');

%初始条件
theta0v = [0 0 0 0 0 0];%初始位置速度
theta0a = [0 0 0 0 0 0];%初始位置加速度
theta3v = [0 0 0 0 0 0];%目标位置速度
theta3a = [0 0 0 0 0 0];%目标位置加速度

Theta = [theta0' theta0v' theta0a' theta1' theta1' zeros(6,1) zeros(6,1) theta2' theta2' zeros(6,1) zeros(6,1) theta3' theta3v' theta3a']';
    
M = [1     0    0      0       0       0       0       0          0         0         0     0    0      0
     0     1    0      0       0       0       0       0          0         0         0     0    0      0
     0     0    2      0       0       0       0       0          0         0         0     0    0      0 
     1     t1   t1^2   t1^3    0       0       0       0          0         0         0     0    0      0 
     0     0    0      0       1       t1      t1^2    t1^3       t1^4      t1^5      0     0    0      0 
     0     1    2*t1   3*t1^2  0       -1     -2*t1   -3*t1^2    -4*t1^3   -5*t1^4    0     0    0      0 
     0     0    2      6*t1    0       0      -2      -6*t1      -12*t1^2  -20*t1^3   0     0    0      0 
     0     0    0      0       1       t2      t2^2    t2^3       t2^4      t2^5      0     0    0      0 
     0     0    0      0       0       0       0       0          0         0         1     t2   t2^2   t2^3
     0     0    0      0       0       1       2*t2    3*t2^2     4*t2^3    5*t2^4    0    -1   -2*t2  -3*t3^2
     0     0    0      0       0       0       2       6*t2       12*t2^2   20*t2^3   0     0    0      0 
     0     0    0      0       0       0       0       0          0         0         1     t3   t3^2   t3^3
     0     0    0      0       0       0       0       0          0         0         0     1    2*t3   3*t3^2
     0     0    0      0       0       0       0       0          0         0         0     0    2      6*t3];
  
 C = M^-1 * Theta;
 
 time_points = linspace(0, 15, 180);
% 计算各阶段的关节角度Q
Q = zeros(180,6);
for i = 1:180
    t = time_points(i);
    if 0 <= t && t < t1
        theta(:,1:6) = C(1,1:6)+C(2,1:6)*t + C(3,1:6)*t.^2 + C(4,1:6)*t.^3;
        Q(i,:) = theta(:,1:6);
    elseif t1 <= t && t < t2
        theta(:,1:6) = C(5,1:6)+C(6,1:6)*t + C(7,1:6)*t.^2 + C(8,1:6)*t.^3 + C(9,1:6)*t.^4 + C(10,1:6)*t.^5;
        Q(i,:) = theta(:,1:6);
    elseif t2 <= t && t <= 15
        theta(:,1:6) = C(11,1:6)+C(12,1:6)*t + C(13,1:6)*t.^2 + C(14,1:6)*t.^3;
        Q(i,:) = theta(:,1:6);
    end
end

% 计算各阶段的关节速度Qv
Qv = zeros(180,6);
for i = 1:180
    t = time_points(i);
    if 0 <= t && t < t1
        theta(:,1:6) = C(2,1:6) + 2*C(3,1:6)*t + 3*C(4,1:6)*t.^2;
        Qv(i,:) = theta(:,1:6);
    elseif t1 <= t && t < t2
        theta(:,1:6) = C(6,1:6) + 2*C(7,1:6)*t + 3*C(8,1:6)*t.^2 + 4*C(9,1:6)*t.^3 + 5*C(10,1:6)*t.^4;
        Qv(i,:) = theta(:,1:6);
    elseif t2 <= t && t <= 15
        theta(:,1:6) = C(12,1:6) + 2*C(13,1:6)*t + 3*C(14,1:6)*t.^2;
        Qv(i,:) = theta(:,1:6);
    end
end

% 计算各阶段的关节加速度Qa
Qa = zeros(180,6);
for i = 1:180
    t = time_points(i);
    if 0 <= t && t < t1
        theta(:,1:6) = 2*C(3,1:6) + 6*C(4,1:6)*t;
        Qa(i,:) = theta(:,1:6);
    elseif t1 <= t && t < t2
        theta(:,1:6) = 2*C(7,1:6) + 6*C(8,1:6)*t + 12*C(9,1:6)*t.^2 + 20*C(10,1:6)*t.^3;
        Qa(i,:) = theta(:,1:6);
    elseif t2 <= t && t <= 15
        theta(:,1:6) = 2*C(13,1:6) + 6*C(14,1:6)*t;
        Qa(i,:) = theta(:,1:6);
    end
end


% 正运动学分析
Txy = p560.fkine(Q);
% 画轨迹
Tjtraj1 = transl(Txy);
x = Tjtraj1(:,1);
y = Tjtraj1(:,2);
z = Tjtraj1(:,3);
figure
waitforbuttonpress;
plot3(x,y,z,'b'); % 轨迹图像
hold on;

% 画出四个过程点
[x0,y0,z0]  = ellipsoid(aim0(1),aim0(2),aim0(3),0.05,0.05,0.05);
[x1,y1,z1]  = ellipsoid(aim1(1),aim1(2),aim1(3),0.05,0.05,0.05);
[x2,y2,z2]  = ellipsoid(aim2(1),aim2(2),aim2(3),0.05,0.05,0.05);
[xx,yx,zx]  = ellipsoid(aim3(1),aim3(2),aim3(3),0.05,0.05,0.05);
surf(x0,y0,z0) % 画起始点
surf(x1,y1,z1) % 画第一个中间点
surf(x2,y2,z2) % 画第二个中间点
surf(xx,yx,zx) % 画目标点
hold on;

% 画轨迹图
p560.plot(Q);

% 画关节位置、速度、加速度曲线
figure
subplot(3,1,1);
plot(time_points,Q);
title('关节位移');
xlabel('时间t/s');
ylabel('位移s/rad');
legend('关节1','关节2','关节3','关节4','关节5','关节6','location','northeastoutside' );
grid on;
subplot(3,1,2);
plot(time_points,Qv);
title('关节速度');
xlabel('时间t/s');
ylabel('速度v/(rad/s)');
legend('关节1','关节2','关节3','关节4','关节5','关节6','location','northeastoutside' );
grid on;
subplot(3,1,3);
plot(time_points,Qa);
title('关节加速度');
xlabel('时间t/s');
ylabel('加速度a/(rad/s^2)');
legend('关节1','关节2','关节3','关节4','关节5','关节6','location','northeastoutside' );
grid on;